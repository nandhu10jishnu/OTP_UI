import React, { useState } from 'react';

function App() {
  const [email, setEmail] = useState('');
  const [otp, setOtp] = useState('');
  const [isOTPGenerated, setIsOTPGenerated] = useState(false);

  const handleEmailChange = (e) => {
    setEmail(e.target.value);
  };

  const handleOTPChange = (e) => {
    setOtp(e.target.value);
  };

  const handleGenerateOTP = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch('/api/send-otp', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email }),
      });

      if (response.ok) {
        setIsOTPGenerated(true);
      } else {
        console.error('Failed to generate OTP');
      }
    } catch (error) {
      console.error('Error generating OTP:', error);
    }
  };

  const handleVerifyOTP = async (e) => {
    e.preventDefault();
    console.log('EMAIL: '+email);
    try {
      const response = await fetch('/api/verify-otp', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, otp }),
      });

      if (response.ok) {
        // Redirect to the welcome page
        window.location.href = '/welcome';
      } else {
        console.error('Invalid OTP');
      }
    } catch (error) {
      console.error('Error verifying OTP:', error);
    }
  };

  return (
    <div>
      {isOTPGenerated ? (
        <form onSubmit={handleVerifyOTP}>
          <label htmlFor="otp">Enter OTP:</label>
          <input
            type="text"
            id="otp"
            value={otp}
            onChange={handleOTPChange}
          />
          <button type="submit">Submit</button>
        </form>
      ) : (
        <form onSubmit={handleGenerateOTP}>
          <label htmlFor="email">Email:</label>
          <input
            type="email"
            id="email"
            value={email}
            onChange={handleEmailChange}
          />
          <button type="submit">Submit</button>
        </form>
      )}
    </div>
  );
}

export default App;
